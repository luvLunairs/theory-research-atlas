"""Exact small-instance checks for rounded-phase robust cores.

No project theorem/solver imports. All exceptional-owner maps are included.
The phase union is compared with the integer-compensation criterion, then
a bounded subset is independently checked by literal complete allocations
at the sufficient compensation pool T.
"""
from itertools import product
from fractions import Fraction as F
from math import lcm
from pathlib import Path
import hashlib, json, random


def compositions(k,n):
    if n==1:
        yield (k,)
    else:
        for x in range(k+1):
            for tail in compositions(k-x,n-1):
                yield (x,)+tail


def literal_efx(owner, low, sets, num, den):
    n=len(low)
    bundles=[[g for g,j in enumerate(owner)if j==i]for i in range(n)]
    checks=0
    for i in range(n):
        own=sum(num[i]if g in sets[i]else den[i]for g in bundles[i])+den[i]*low[i]
        for j in range(n):
            values=[num[i]if g in sets[i]else den[i]for g in bundles[j]]+[den[i]]*low[j]
            for removed in values:
                assert own>=sum(values)-removed,(i,j,owner,low)
                checks+=1
    return checks


def main():
    rng=random.Random(204081)
    stats=dict(profiles=0,owner_maps=0,utility_vectors=0,phase_vectors=0,
               robust_vectors=0,phase_selected_vectors=0,
               compensation_pairs=0,literal_threshold_checks=0,
               literal_complete_allocation_classes=0,
               balanced_efx_deletions=0,finite_pool_exchange_checks=0,
               finite_pool_literal_classes=0)
    palette=[F(6,5),F(3,2),F(8,5),F(2),F(7,3),F(11,4),F(3),F(5)]
    profiles=[]
    for a,b in product(palette[:4],repeat=2):
        profiles.append(([a,b],[{0,1,2},{0,1,2}],3))
    for t in range(64):
        n=2+t%3; G=1+t%4
        if n==4:G=min(G,3)
        r=[rng.choice(palette)for _ in range(n)]
        sets=[set()for _ in range(n)]
        for g in range(G):
            liked=[i for i in range(n)if rng.randrange(2)] or [rng.randrange(n)]
            for i in liked:sets[i].add(g)
        profiles.append((r,sets,G))
    for trial,(r,sets,G) in enumerate(profiles):
        n=len(r);num=[x.numerator for x in r];den=[x.denominator for x in r]
        scale=lcm(*den);weights=[scale//x for x in den]
        utility_owners={};lowheld={}
        owners=list(product(range(n),repeat=G))
        for owner in owners:
            u=[0]*n;bad=False
            for g,i in enumerate(owner):
                good=g in sets[i];u[i]+=num[i]if good else den[i]
                bad|=not good
            u=tuple(u);utility_owners.setdefault(u,owner)
            lowheld[u]=lowheld.get(u,False)or bad
        vectors=list(utility_owners)
        stats['profiles']+=1;stats['owner_maps']+=len(owners)
        stats['utility_vectors']+=len(vectors)
        welfare={u:sum(a*w for a,w in zip(u,weights))for u in vectors}
        robust=set()
        for v in vectors:
            safe=True
            for w in vectors:
                d=[-((w[i]-v[i])//den[i])for i in range(n)]
                stats['compensation_pairs']+=1
                if sum(d)<0 or(sum(d)==0 and any(w[i]+den[i]*d[i]>v[i]for i in range(n))):
                    safe=False;break
            if safe:robust.add(v)
        phases=[sorted({(num[i]*h)%den[i]for h in range(len(sets[i])+1)})for i in range(n)]
        selected=set()
        for phase in product(*phases):
            scores={u:(sum((u[i]-phase[i])//den[i]+1 for i in range(n)),welfare[u])for u in vectors}
            best=max(scores.values())
            selected.update(u for u,s in scores.items()if s==best)
            stats['phase_vectors']+=1
        assert selected==robust,(trial,r,sets,selected-robust,robust-selected)
        assert all(not lowheld[u]for u in robust)
        stats['robust_vectors']+=len(robust);stats['phase_selected_vectors']+=len(selected)
        maximum=max(welfare.values())
        for v in robust:
            assert maximum-welfare[v]<(n-1)*scale
            M=max(v[i]//den[i]for i in range(n))
            low=tuple(M-v[i]//den[i]for i in range(n))
            stats['balanced_efx_deletions']+=literal_efx(utility_owners[v],low,sets,num,den)
        # Independent finite-pool test: for each alternate core, enumerate
        # every final low composition and compare against the capped-sum
        # activation inequality. Include zero-gain and low-held alternatives.
        if n<=3 and trial%5==0:
            for K in range(4):
                pool=list(compositions(K,n))
                for v in vectors[::max(1,len(vectors)//3)][:3]:
                    for low in pool:
                        target=tuple(v[i]+den[i]*low[i]for i in range(n))
                        for w in vectors:
                            direct=False
                            for newlow in pool:
                                actual=tuple(w[i]+den[i]*newlow[i]for i in range(n))
                                direct|=all(a>=b for a,b in zip(actual,target))and actual!=target
                                stats['finite_pool_literal_classes']+=1
                            d=[-((w[i]-v[i])//den[i])for i in range(n)]
                            P=sum(max(x,0)for x in d)
                            release=sum(min(low[i],max(-d[i],0))for i in range(n))
                            predicted=welfare[w]>welfare[v]and release>=P
                            assert direct==predicted,(trial,v,low,w,P,release)
                            stats['finite_pool_exchange_checks']+=1
        # Independent direct threshold enumeration, including all low-held
        # exceptional assignments and all low-count compositions.
        if n<=3 and trial%4==0:
            total=[sum(num[i]if g in sets[i]else den[i]for g in range(G))for i in range(n)]
            for v in vectors[::max(1,len(vectors)//3)][:3]:
                T=tuple(-((v[i]-total[i])//den[i])for i in range(n));K=sum(T)
                if K>9:continue
                target=tuple(v[i]+den[i]*T[i]for i in range(n))
                dominated=False;pool=list(compositions(K,n))
                for owner in owners:
                    base=[0]*n
                    for g,i in enumerate(owner):base[i]+=num[i]if g in sets[i]else den[i]
                    for low in pool:
                        u=tuple(base[i]+den[i]*low[i]for i in range(n))
                        if all(a>=b for a,b in zip(u,target))and u!=target:dominated=True
                        stats['literal_complete_allocation_classes']+=1
                assert (v in robust)==(not dominated),(trial,v,T)
                stats['literal_threshold_checks']+=1
    # Sharp welfare-gap family. Verify the exact resource deficit for every
    # exceptional-owner map, not only for high-held reallocations.
    sharp=[]
    for n in range(2,6):
        eps=F(1,10*n);r0=1+eps;rs=2-eps;G=n-1
        minimum=None
        for owner in product(range(n),repeat=G):
            W=[F(0)]*n
            for g,i in enumerate(owner):W[i]+=r0 if i==0 else rs if i==g+1 else 1
            V=[r0*G]+[F(0)]*(n-1)
            d=[-((W[i]-V[i]).numerator//(W[i]-V[i]).denominator)for i in range(n)]
            assert sum(d)>0 or(sum(d)==0 and W==V)
            if owner!=(0,)*G:minimum=sum(d)if minimum is None else min(minimum,sum(d))
        sharp.append(dict(n=n,epsilon=str(eps),welfare_gap=str(G*(rs-r0)),minimum_nontrivial_compensation=minimum))
    # Literal EFX and PO at pool zero for the two finite-pool examples.
    examples=[]
    for ratios,expected_threshold in [([F(3,2),F(8,5)],3),([F(2),F(3)],4)]:
        n=2;sets=[set(range(3)),set(range(3))]
        num=[x.numerator for x in ratios];den=[x.denominator for x in ratios]
        owner=(0,1,1);target=[num[0],2*num[1]]
        literal_efx(owner,(0,0),sets,num,den)
        assert not any(all((sum(i==j for j in other)*num[i])>=target[i]for i in range(n))
                       and any((sum(i==j for j in other)*num[i])>target[i]for i in range(n))
                       for other in product(range(n),repeat=3))
        # Maximum-ratio core owner=(1,1,1): direct EFX feasibility by K.
        first=None
        for K in range(expected_threshold+1):
            for low in compositions(K,n):
                try:literal_efx((1,1,1),low,sets,num,den)
                except AssertionError:continue
                first=K;break
            if first is not None:break
        assert first==expected_threshold
        examples.append(dict(ratios=[str(r)for r in ratios],split_core_efx_po_at_pool=0,
                             max_ratio_core_least_efx_pool=first))
    # Exact coupled obstruction: a 4-cycle source/sink exchange. This is a
    # small specialization of the regular bipartite exchange family from v6,
    # used only to witness that the PO low set need not be one box.
    n=4;G=4;num=[6,6,7,7];den=[4]*4
    sets=[{0,1},{2,3},{0,2},{1,3}];V=(12,12,0,0)
    owner_vectors=[];activation=set()
    for owner in product(range(n),repeat=G):
        W=tuple(sum(num[i]if g in sets[i]else den[i]for g,j in enumerate(owner)if j==i)for i in range(n))
        owner_vectors.append(W)
        if sum(W)<=sum(V):continue
        d=[-((W[i]-V[i])//4)for i in range(n)]
        P=sum(max(x,0)for x in d);t=[max(-x,0)for x in d]
        for b in compositions(P,n):
            if all(b[i]<=t[i]for i in range(n)):activation.add(b)
    antichain=sorted(b for b in activation if not any(a!=b and all(a[i]<=b[i]for i in range(n))for a in activation))
    assert antichain==[(0,0,3,3)],antichain
    coupled_classes=0
    for a,b in product(range(4),repeat=2):
        target=(12,12,4*a,4*b);dominated=False
        for W in owner_vectors:
            for low in compositions(a+b,n):
                actual=tuple(W[i]+4*low[i]for i in range(n))
                dominated|=all(actual[i]>=target[i]for i in range(n))and actual!=target
                coupled_classes+=1
        assert dominated==(a==b==3),(a,b)
    # Independent literal endpoint check for the integer-ratio example.
    endpoint=[];endpoint_classes=0
    for x,y in product(range(8),repeat=2):
        target=(2+x,6+y);dominated=False
        for owner in product(range(2),repeat=3):
            base=(2*owner.count(0),3*owner.count(1))
            for low in compositions(x+y,2):
                actual=(base[0]+low[0],base[1]+low[1])
                dominated|=all(actual[i]>=target[i]for i in range(2))and actual!=target
                endpoint_classes+=1
        assert dominated==(y>=2),(x,y)
        try:literal_efx((0,1,1),(x,y),[set(range(3))]*2,[2,3],[1,1])
        except AssertionError:continue
        if not dominated:endpoint.append(x+y)
    assert sorted(set(endpoint))==list(range(7))
    out=dict(status='PASS',seed=204081,stats=stats,sharp_gap_examples=sharp,
             finite_pool_examples=examples,
             coupled_obstruction=dict(minimal_activation_vectors=antichain,
                                      literal_classes=coupled_classes,
                                      initial_sink_low_grid='0..3 in each sink; source lows 0'),
             finite_endpoint=dict(attained_totals=sorted(set(endpoint)),
                                  initial_low_grid='0..7 in each agent',
                                  literal_classes=endpoint_classes),
             script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             scope='Finite exact checks of phase characterization, balanced EFX completion, welfare-gap bound, and finite-pool capped-sum criterion, with independent literal allocation tests. No unrestricted existence claim.')
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
