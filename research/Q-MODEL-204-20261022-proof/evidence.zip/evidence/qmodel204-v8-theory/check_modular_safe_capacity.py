"""Exact finite checks of modular-safe-capacity-existence.txt; stdlib only."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
import random


def floor(x):
    return x.numerator // x.denominator


def ceil(x):
    return -((-x.numerator) // x.denominator)


def safe(alpha, r, d):
    s = 0
    for u in range(1, d + 1):
        if floor(r*u) != floor(alpha*u):
            break
        s = u
    return s


def literal_efx(high_sets, ratios, owners, lows):
    n = len(ratios)
    bundles = [[g for g, owner in enumerate(owners) if owner == i]
               for i in range(n)]
    U = [sum((ratios[i] if g in high_sets[i] else F(1)
              for g in bundles[i]), F(lows[i])) for i in range(n)]
    checks = 0
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            vals = [ratios[i] if g in high_sets[i] else F(1)
                    for g in bundles[j]] + [F(1)]*lows[j]
            total = sum(vals, F(0))
            for v in vals:
                assert U[i] >= total-v, (high_sets, ratios, owners, lows, i, j)
                checks += 1
    return checks


def check(alpha, ratios, high_sets, stats):
    n, k = len(ratios), alpha.denominator
    G = max((g for s in high_sets for g in s), default=-1) + 1
    degrees = [len(s) for s in high_sets]
    capacity = [safe(alpha, r, d) for r, d in zip(ratios, degrees)]
    quota = [d-s for d, s in zip(degrees, capacity)]
    alternatives, candidates = [], []
    for owners in product(range(n), repeat=G):
        h = tuple(sum(owner == i and g in high_sets[i]
                      for g, owner in enumerate(owners)) for i in range(n))
        counts = tuple(owners.count(i) for i in range(n))
        W = tuple(counts[i] + (ratios[i]-1)*h[i] for i in range(n))
        alternatives.append(W)
        if sum(h) == G and all(h[i] % k == 0 and h[i] >= quota[i]
                              for i in range(n)):
            score = sum(h[i] for i in range(n) if ratios[i] > alpha)
            candidates.append((score, owners, h))
    stats["profiles_examined"] += 1
    if not candidates:
        stats["infeasible_profiles"] += 1
        return
    stats["feasible_profiles"] += 1
    stats["alpha_counts"][str(alpha)] = stats["alpha_counts"].get(str(alpha), 0) + 1
    best = max(score for score, _, _ in candidates)
    seen = set()
    for score, owners, h in candidates:
        if score != best:
            continue
        stats["maximizing_core_maps"] += 1
        if h in seen:
            continue
        seen.add(h)
        stats["distinct_selected_high_count_vectors"] += 1
        V = tuple(ratios[i]*h[i] for i in range(n))
        for W in alternatives:
            compensation = [ceil(V[i]-W[i]) for i in range(n)]
            assert sum(compensation) >= 0, (alpha, ratios, high_sets, owners, W)
            if sum(compensation) == 0:
                assert all(W[i]+compensation[i] == V[i] for i in range(n))
            stats["complete_core_reassignment_comparisons"] += 1
        M = max(map(floor, V))
        lows = [M-floor(v) for v in V]
        stats["literal_deletion_inequalities"] += literal_efx(high_sets, ratios, owners, lows)
        if all(d <= 2*k-1 for d in degrees):
            B = ceil(alpha*(k-1))
            small_lows = [B if c == 0 else 0 for c in h]
            assert sum(small_lows) == B*(n-G//k)
            stats["literal_deletion_inequalities"] += literal_efx(
                high_sets, ratios, owners, small_lows)
            stats["sharper_pool_checks"] += 1
        unsaturated = any(ratios[i] > alpha and 0 < h[i] < degrees[i]
                          for i in range(n))
        beyond_small_band = any(ratios[i] > alpha and
                                (ratios[i]-alpha)*degrees[i] >= F(1, k)
                                for i in range(n))
        stats["unsaturated_positive_ratio_holders"] += int(unsaturated)
        stats["selected_vectors_beyond_small_perturbation_bound"] += int(beyond_small_band)
        if unsaturated and beyond_small_band and len(stats["examples"]) < 5:
            stats["examples"].append({"alpha": str(alpha), "ratios": list(map(str, ratios)),
                "high_sets": [sorted(s) for s in high_sets], "capacity": capacity,
                "quota": quota, "owners": owners, "high_counts": h,
                "balanced_lows": lows})


if __name__ == "__main__":
    rng = random.Random(20480822)
    stats = {"profiles_examined": 0, "infeasible_profiles": 0, "feasible_profiles": 0,
             "maximizing_core_maps": 0, "distinct_selected_high_count_vectors": 0,
             "complete_core_reassignment_comparisons": 0, "literal_deletion_inequalities": 0,
             "sharper_pool_checks": 0, "unsaturated_positive_ratio_holders": 0,
             "selected_vectors_beyond_small_perturbation_bound": 0,
             "alpha_counts": {}, "examples": []}
    for alpha in (F(1), F(3,2), F(5,3), F(7,3), F(2)):
        k = alpha.denominator
        for case in range(60):
            n = 3
            G = k*(1 + case % (6//k))
            masks = [rng.randrange(1, 1 << n) for _ in range(G)]
            high_sets = [set(g for g, mask in enumerate(masks) if mask >> i & 1)
                         for i in range(n)]
            ratios = []
            for i in range(n):
                d = max(1, len(high_sets[i]))
                choices = [alpha+F(1, 2*k*d), alpha+F(1,2*k), alpha+F(1,k), alpha+2]
                if alpha > 1:
                    choices += [alpha, alpha]
                ratios.append(rng.choice(choices))
            check(alpha, tuple(ratios), high_sets, stats)
    check(F(1), (F(7,3),), [set()], stats)
    check(F(3,2), (F(19,7),), [{0,1,2,3}], stats)
    # A selected core can have a genuinely higher-degree unsaturated sink.
    check(F(3,2), (F(3,2), F(7,4), F(3,2)),
          [{0,1}, {0,1,2,3,4}, {2,3,4,5}], stats)
    # The maximization cannot simply be omitted at a mixed endpoint.
    V, W = (F(3), F(0)), (F(0), F(7,2))
    D = [ceil(V[i]-W[i]) for i in range(2)]
    assert sum(D) == 0 and W[1]+D[1] > V[1]
    data = {"status": "PASS", "seed": 20480822,
            "scope": "Finite exact checks; all candidate core reassignments include low-held goods",
            "selection_necessity_witness": {"ratios": ["3/2", "7/4"],
                "two_goods_high_to_both": True, "unselected_core_high_counts": [2,0],
                "alternative_high_counts": [0,2], "compensation": D}, "results": stats}
    Path(__file__).with_suffix(".json").write_text(json.dumps(data, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(data, indent=2))
