"""Independent count-class recheck of efx-nash-family-analytic.txt; stdlib."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json


def ceil(x):
    return -((-x.numerator) // x.denominator)


def allocations(t):
    ratios = (F(3), F(4), t)
    high_sets = ({0, 1}, {0, 1, 2, 3}, {0, 1, 2, 4})
    for owners in product(range(3), repeat=5):
        bundles = [[g for g, owner in enumerate(owners) if owner == i]
                   for i in range(3)]
        view = [[sum((ratios[i] if g in high_sets[i] else F(1)
                      for g in bundles[j]), F(0)) for j in range(3)]
                for i in range(3)]
        for x in range(8):
            for y in range(8 - x):
                lows = (x, y, 7 - x - y)
                U = tuple(view[i][i] + lows[i] for i in range(3))
                efx = True
                for i in range(3):
                    for j in range(3):
                        if i == j:
                            continue
                        vals = [ratios[i] if g in high_sets[i] else F(1)
                                for g in bundles[j]] + [F(1)] * lows[j]
                        if any(U[i] < view[i][j] + lows[j] - v for v in vals):
                            efx = False
                yield owners, lows, U, efx


def check(t):
    N = 128 * (t + 1)
    target = (F(8), F(8), 2 * t + 2)
    Y = (F(8), F(8), t + 5)
    Z = (F(7), F(8), t + 6)
    total = efx_count = maximizers = 0
    all_utilities, efx_utilities = set(), set()
    z_seen = False
    for owners, lows, U, efx in allocations(t):
        total += 1
        all_utilities.add(U)
        if efx:
            efx_utilities.add(U)
            efx_count += 1
            assert U[0] * U[1] * U[2] <= N
            if U[0] * U[1] * U[2] == N:
                assert U == target
                assert all(Y[i] >= U[i] for i in range(3)) and Y[2] > U[2]
                maximizers += 1
        if owners == (0, 0, 1, 1, 2) and lows == (1, 0, 6):
            assert U == Z and efx
            z_seen = True
        assert not (all(U[i] >= Z[i] for i in range(3)) and U != Z)
    assert maximizers and z_seen
    efx_po = [U for U in efx_utilities if not any(
        W != U and all(W[i] >= U[i] for i in range(3)) for W in all_utilities)]
    best_po_product = max(U[0]*U[1]*U[2] for U in efx_po)
    assert best_po_product == 56*(t+6)
    assert {U for U in efx_po if U[0]*U[1]*U[2] == best_po_product} == {Z}
    requirements = [[h + max(0, ceil(Z[i] - r * h))
                     for h in range(d + 1)]
                    for i, (r, d) in enumerate(zip((F(3), F(4), t), (2, 4, 4)))]
    assert requirements == [[7, 5, 3], [8, 5, 2, 3, 4], [9, 7, 6, 4, 4]]
    minima = []
    for b in range(5):
        costs = [(requirements[0][a] + requirements[1][b] + requirements[2][c],
                  (a, b, c)) for a in range(3) for c in range(5) if a+b+c <= 5]
        minima.append(min(v for v, _ in costs))
        if b == 2:
            assert [h for v, h in costs if v == 12] == [(2, 2, 1)]
    assert minima == [15, 14, 12, 15, 18]
    return {"t": str(t), "complete_count_allocations": total,
            "efx_count_allocations": efx_count, "efx_nash_maximizers": maximizers,
            "maximum_efx_product": str(N), "witness_Z_product": str(56*(t+6)),
            "all_utility_vectors": len(all_utilities), "efx_utility_vectors": len(efx_utilities),
            "efx_po_utility_vectors": len(efx_po), "best_efx_po_product": str(best_po_product),
            "resource_minima_by_B_high_count": minima}


if __name__ == "__main__":
    cases = [F(26,9) + F(1,9) * q for q in
             (F(1,100), F(1,10), F(1,2), F(9,10), F(99,100))]
    for t, a, b in ((F(26,9), F(215,27), F(77,12)),
                    (F(3), F(5), F(23,4))):
        assert -12*t*t + 44*t - 19 == a
        assert -9*t*t + 47*t - F(217,4) == b
        assert 128*(t+1) - (t+5)**3 == (3-t)*(t*t+18*t+1)
    rows = [check(t) for t in cases]
    out = {"status": "PASS", "scope": "Finite rational recheck of symbolic interval proof",
           "cases": rows, "total_complete_count_allocations":
           sum(r["complete_count_allocations"] for r in rows)}
    Path(__file__).with_suffix(".json").write_text(json.dumps(out, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(out, indent=2))
