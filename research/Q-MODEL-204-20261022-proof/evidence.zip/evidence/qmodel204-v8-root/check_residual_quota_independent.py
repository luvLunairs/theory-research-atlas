"""Independent exact checks of the residual-quota core theorem.

No imports from project solvers or the theorem author's implementation.
All complete core owner maps are enumerated, including low-held core goods.
Separate small-pool checks enumerate all low-count compositions literally.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from collections import Counter
import hashlib, json, random

def ceil(x): return -((-x.numerator)//x.denominator)
def floor(x): return x.numerator//x.denominator
def comp(s,n):
    if n==1:
        yield (s,)
    else:
        for x in range(s+1):
            for rest in comp(s-x,n-1): yield (x,)+rest

def main():
    rng=random.Random(2040822); stats=Counter(); examples=[]
    cases=[]
    # Complete two-agent incidence patterns, small denominators and boundary ratios.
    for G in (2,3,4):
        for types in product((1,2,3),repeat=G):
            for alpha in (F(1),F(3,2),F(5,3),F(2)):
                if G%alpha.denominator: continue
                for r in ((alpha+F(1,10),alpha+F(2,5)),
                          (alpha if alpha>1 else F(11,10),alpha+F(1,3)),
                          (alpha if alpha>1 else F(6,5),F(7))):
                    cases.append((alpha,r,types))
    # Random incidences with larger residual degrees and arbitrary-ratio saturated agents.
    for z in range(140):
        n=3;alpha=rng.choice((F(1),F(3,2),F(5,3),F(7,3),F(2)))
        G=6 if alpha.denominator>1 else 4+z%3
        r=tuple(alpha+(rng.choice((F(0),F(1,20),F(1,5),F(1),F(23,3)))) for _ in range(n))
        if min(r)<=1:continue
        types=tuple(rng.randrange(1,1<<n)for _ in range(G))
        cases.append((alpha,r,types))
    # Explicit higher-degree unsaturated holders, and a large-ratio saturated holder.
    cases.extend([
        (F(5,3),(F(5,3),F(19,10)),(3,1,1,2,2,2)),
        (F(5,3),(F(5,3),F(19,10),F(100)),(3,1,1,2,2,2,4,4,4)),
        (F(3,2),(F(3,2),F(8,5)),(3,3,1,1,2,2,2,2)),
    ])
    for case_id,(alpha,r,types) in enumerate(cases):
        n=len(r);G=len(types);k=alpha.denominator
        degree=[sum(bool(t>>i&1)for t in types)for i in range(n)]
        safe=[]
        for i in range(n):
            s=0
            for u in range(1,degree[i]+1):
                if floor(r[i]*u)>alpha*u:break
                s=u
            safe.append(s)
        quota=[degree[i]-safe[i]for i in range(n)]
        owners=list(product(range(n),repeat=G));vectors=[];admissible=[]
        for owner in owners:
            W=[F(0)]*n;h=[0]*n
            for t,i in zip(types,owner):
                high=bool(t>>i&1);W[i]+=r[i]if high else 1;h[i]+=high
            vectors.append(tuple(W))
            if sum(h)==G and all(h[i]%k==0 and h[i]>=quota[i]for i in range(n)):
                admissible.append((sum(h[i]for i in range(n)if r[i]>alpha),owner,tuple(h)))
        stats['profiles']+=1
        if not admissible:
            stats['infeasible_quota_profiles']+=1;continue
        stats['feasible_profiles']+=1
        best=max(row[0]for row in admissible)
        chosen=[row for row in admissible if row[0]==best]
        # Deduplicate only identical own-count vectors; preserve one owner map for EFX.
        chosen={row[2]:row[1]for row in chosen}
        for counts,owner in chosen.items():
            stats['maximizing_count_vectors']+=1
            V=tuple(r[i]*counts[i]for i in range(n))
            for W in vectors:
                d=[ceil(V[i]-W[i])for i in range(n)]
                total=sum(d)
                assert total>=0 and (total!=0 or all(W[i]+d[i]==V[i]for i in range(n))), (case_id,alpha,r,types,counts,W,d)
                stats['complete_core_compensation_comparisons']+=1
            M=max(map(floor,V));low=tuple(M-floor(v)for v in V)
            actual=tuple(V[i]+low[i]for i in range(n))
            for i in range(n):
                for j in range(n):
                    goods=[(r[i]if t>>i&1 else F(1))for t,o in zip(types,owner)if o==j]+[F(1)]*low[j]
                    for g in goods:
                        assert actual[i]>=sum(goods)-g,(case_id,counts,low,i,j)
                        stats['literal_EFX_deletions']+=1
            # Completely separate finite allocation check, no ceil compensation.
            if case_id%43==0 and sum(low)<=8 and n<=3:
                for W in vectors:
                    for altlow in comp(sum(low),n):
                        U=tuple(W[i]+altlow[i]for i in range(n))
                        assert not(all(U[i]>=actual[i]for i in range(n))and U!=actual)
                        stats['literal_complete_pool_comparisons']+=1
                stats['literal_pool_instances']+=1
            if case_id>=len(cases)-3:
                examples.append(dict(alpha=str(alpha),ratios=list(map(str,r)),types=types,
                    degree=degree,safe=safe,quota=quota,selected_counts=counts,
                    owner=owner,baseline_low=low,K0=sum(low)))
            if all(d<=2*k-1 for d in degree):
                B=ceil(alpha*(k-1));l=[B if c==0 else 0 for c in counts]
                for step in range(4):
                    U=[V[i]+l[i]for i in range(n)]
                    cross=[[sum((r[i]if t>>i&1 else F(1))for t,o in zip(types,owner)if o==j)+l[j]for j in range(n)]for i in range(n)]
                    for i in range(n):
                        for j in range(n):
                            goods=[(r[i]if t>>i&1 else F(1))for t,o in zip(types,owner)if o==j]+[F(1)]*l[j]
                            assert all(U[i]>=sum(goods)-g for g in goods)
                            stats['sharper_pool_EFX_deletions']+=len(goods)
                    candidates=[j for j in range(n)if all(U[i]>=cross[i][j]for i in range(n))]
                    assert candidates
                    l[candidates[0]]+=1
                stats['sharper_pool_instances']+=1
    # Negative controls: dropping maximality or the safe residual quota fails.
    negatives=[]
    for label,r,types,owner,low,newowner,newlow in [
        ('omit maximality',(F(3,2),F(7,4)),(3,3),(0,0),(0,3),(1,1),(3,0)),
        ('omit residual quota',(F(3,2),F(2)),(3,1),(0,0),(0,2),(1,0),(2,0)),
    ]:
        def utility(o,l):return tuple(sum((r[i]if t>>i&1 else 1)for t,j in zip(types,o)if j==i)+l[i]for i in range(2))
        old=utility(owner,low);new=utility(newowner,newlow)
        assert all(a>=b for a,b in zip(new,old))and new!=old
        negatives.append(dict(label=label,ratios=list(map(str,r)),types=types,old=list(map(str,old)),new=list(map(str,new))))
    out=dict(status='PASS',seed=2040822,stats=dict(stats),explicit_higher_degree_examples=examples,
        negative_controls=negatives,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        scope='Independent finite exact tests of the residual-quota theorem including all maximizing count vectors and all complete core competitors; literal EFX and separate literal complete low-pool checks. Not an unrestricted existence proof or formal certification.')
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
