"""Independent complete-count enumeration and direct Pareto bitset check.

No project solver imports. Checks all complete allocations up to permutations
of identically valued goods. EFX tests remove every available good type.
"""
from pathlib import Path
from itertools import product
from fractions import Fraction as F
import argparse, hashlib, json, math, time
import numpy as np

def compositions(total,n):
    if n==1:yield(total,);return
    for t in range(total+1):
        for tail in compositions(total-t,n-1):yield(t,)+tail

def packed(mask):return int.from_bytes(np.packbits(mask,bitorder='little').tobytes(),'little')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input');ap.add_argument('--output',default='verify_efx_nash_obstruction.json');args=ap.parse_args()
    instance=json.loads(Path(args.input).read_text())if args.input else dict(types=[14,4,13,0,8],counts=[3,1,2,7,1],ratios=['3','59/9','76/5','29/10'])
    types=instance['types'];counts=instance['counts'];r=list(map(F,instance['ratios']));n=len(r);m=sum(counts)
    choices=[list(compositions(c,n))for c in counts];N=math.prod(map(len,choices));start=time.monotonic()
    C=np.array(list(product(*choices)),dtype=np.int16)
    assert C.shape==(N,len(types),n) and np.all(C.sum(axis=2)==counts)
    val=np.array([[x.numerator if t>>i&1 else x.denominator for t in types]for i,x in enumerate(r)],dtype=np.int64)
    utility=np.stack([(C[:,:,i]*val[i]).sum(axis=1)for i in range(n)],axis=1)
    fair=np.ones(N,dtype=bool)
    deletion_checks=0
    for i in range(n):
        for j in range(n):
            if i==j:continue
            target=(C[:,:,j]*val[i]).sum(axis=1)
            for t in range(len(types)):
                present=C[:,t,j]>0;fair &= ~present | (utility[:,i]>=target-val[i,t]);deletion_checks+=int(present.sum())
    assert fair.any()
    assert math.prod(map(int,utility.max(axis=0)))<2**63
    prod=utility.prod(axis=1);best=int(prod[fair].max());top=np.flatnonzero(fair&(prod==best))
    ids=np.flatnonzero(fair);unique={tuple(map(int,utility[k])):int(k)for k in ids}
    thresholds=[sorted({u[i]for u in unique})for i in range(n)]
    ge=[{t:packed(utility[:,i]>=t)for t in thresholds[i]}for i in range(n)]
    gt=[{t:packed(utility[:,i]>t)for t in thresholds[i]}for i in range(n)]
    def dominator(u):
        weak=ge[0][u[0]];strict=gt[0][u[0]]
        for i in range(1,n):weak &=ge[i][u[i]];strict |=gt[i][u[i]]
        possible=weak&strict
        return (possible&-possible).bit_length()-1 if possible else None
    def record(k):
        u=tuple(map(int,utility[k]));owners=[i for t in range(len(types))for i in range(n)for _ in range(int(C[k,t,i]))]
        expanded=[t for t,c in zip(types,counts)for _ in range(c)]
        literal=[sum((r[i]if typ>>i&1 else 1)for typ,o in zip(expanded,owners)if o==i)for i in range(n)]
        assert literal==[F(u[i],r[i].denominator)for i in range(n)]
        edges=[]
        for i in range(n):
            for j in range(n):
                goods=[g for g,o in enumerate(owners)if o==j]
                for g in goods:
                    if literal[i]<sum((r[i]if expanded[h]>>i&1 else 1)for h in goods if h!=g):edges.append([i,j,g])
        assert bool(fair[k])==(not edges)
        return dict(index=k,type_owner_counts=C[k].tolist(),owners=owners,utility=list(map(str,literal)),scaled_utility=u,scaled_product=int(prod[k]),EFX=not edges,strong_envy_deletions=edges)
    bad=[];good=[]
    for u,k in sorted(unique.items()):
        d=dominator(u)
        if d is None:good.append(k)
        elif int(prod[k])==best:bad.append(dict(allocation=record(k),dominator=record(d)))
    assert good,'Potential full counterexample requires further independent certification.'
    bestpo=max(good,key=lambda k:int(prod[k]));topu={tuple(map(int,utility[k]))for k in top}
    result=dict(status='PASS',instance=instance,complete_count_classes=N,EFX_count_classes=int(fair.sum()),
        EFX_utility_vectors=len(unique),EFX_PO_utility_vectors=len(good),
        EFX_PO_scaled_vectors=[list(map(int,utility[k]))for k in good],
        EFX_Nash_count_classes=len(top),EFX_Nash_utility_vectors=len(topu),
        every_EFX_Nash_maximizer_dominated=all(dominator(u)is not None for u in topu),
        maximum_EFX_scaled_product=best,maximum_EFX_PO_scaled_product=int(prod[bestpo]),
        bad_maximizers=bad,best_EFX_PO_witness=record(bestpo),literal_type_deletion_checks=deletion_checks,
        all_allocations_represented=True,seconds=time.monotonic()-start,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        scope='Complete integral allocation classes; every EFX utility vector directly compared against all complete allocation classes. This refutes a selector only if EFX+PO witnesses remain.')
    Path(__file__).with_name(args.output).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k not in{'bad_maximizers','best_EFX_PO_witness'}}),flush=True)

if __name__=='__main__':main()
