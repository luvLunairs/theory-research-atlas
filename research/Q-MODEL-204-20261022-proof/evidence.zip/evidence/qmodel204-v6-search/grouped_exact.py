"""Exact complete EFX enumeration after quotienting identical good columns."""
from fractions import Fraction as F
from itertools import product
import math
import numpy as np
from high_vector_exact import high_vectors,global_dominator,literal_envy,literal_utility

def compositions(K,n):
    if n==1:yield (K,);return
    for x in range(K+1):
        for tail in compositions(K-x,n-1):yield (x,)+tail

class Grouped:
    def __init__(self,n,counts):
        self.n=n;self.counts=tuple(counts);self.m=sum(counts)
        cs=[np.array(list(compositions(k,n)),dtype=np.int16) for k in counts]
        self.classes=math.prod(map(len,cs));self.C=np.empty((self.classes,len(counts),n),dtype=np.int16)
        digits=np.arange(self.classes,dtype=np.int64)
        for t,c in enumerate(cs):self.C[:,t,:]=c[digits%len(c)];digits//=len(c)
        self.S=self.C.sum(axis=1,dtype=np.int16)
        self.types=None

    def set_types(self,types):
        if self.types==tuple(types):return
        self.types=tuple(types);self.expanded=[t for t,k in zip(types,self.counts) for _ in range(k)]
        self.H=np.stack([self.C[:,[t for t,typ in enumerate(types) if typ>>i&1],:].sum(axis=1,dtype=np.int16) for i in range(self.n)])
        nonzero=[t for t in self.expanded if t];self.K=self.expanded.count(0);self.nonzero=nonzero
        self.states=high_vectors(self.n,nonzero);self.hs=np.asarray(list(self.states),dtype=np.int64)

    def data(self,rs):
        a=np.asarray([r.numerator for r in rs],dtype=np.int64);b=np.asarray([r.denominator for r in rs],dtype=np.int64)
        return {'n':self.n,'types':self.nonzero,'K':self.K,'m':self.m,'a':a,'b':b,'ratios':rs,'states':self.states,'hs':self.hs,'base':self.hs*a}

    def expanded_owners(self,k):
        # Grouped original order; independent literal calculations below use this.
        return [i for t in range(len(self.types)) for i,c in enumerate(self.C[k,t]) for _ in range(int(c))]

    def literal(self,k,rs):
        owners=self.expanded_owners(k);values=[[r if typ>>i&1 else F(1) for typ in self.expanded] for i,r in enumerate(rs)]
        u=[sum(values[i][g] for g,o in enumerate(owners) if o==i) for i in range(self.n)];edges=[]
        for i,j in product(range(self.n),repeat=2):
            bundle=[g for g,o in enumerate(owners) if o==j]
            if any(u[i]<sum(values[i][g] for g in bundle if g!=removed) for removed in bundle):edges.append((i,j))
        return u,edges

    def evaluate(self,types,ratios,top_nonpo=0):
        self.set_types(types);rs=list(map(F,ratios));assert all(r>1 for r in rs)
        a=np.asarray([r.numerator for r in rs],dtype=np.int64);b=np.asarray([r.denominator for r in rs],dtype=np.int64)
        U=np.stack([b[i]*self.S[:,i]+(a[i]-b[i])*self.H[i,:,i] for i in range(self.n)],axis=1)
        assert math.prod(map(int,U.max(axis=0)))<2**63
        fair=np.ones(self.classes,dtype=bool)
        for i,j in product(range(self.n),repeat=2):
            if i==j:continue
            minimum=np.where(self.H[i,:,j]<self.S[:,j],b[i],a[i])
            fair&=U[:,i]>=b[i]*self.S[:,j]+(a[i]-b[i])*self.H[i,:,j]-minimum
        assert fair.any(),'No EFX allocation: independently certify before claiming.'
        P=U.prod(axis=1);best=int(P[fair].max());globalbest=int(P.max());winners=np.flatnonzero(fair&(P==best));d=self.data(rs)
        seen=set();bad=[];checked=0
        for k in winners:
            u=tuple(map(int,U[k]));
            if u in seen:continue
            seen.add(u);checked+=1;dom=global_dominator(d,u)
            if dom is not None:
                assert not self.literal(int(k),rs)[1]
                bad.append({'class':int(k),'counts':self.C[k].tolist(),'utility':u,'dominator':dom})
        record={'types':list(types),'counts':self.counts,'ratios':list(map(str,rs)),'EFX_classes':int(fair.sum()),'EFX_MNW_classes':len(winners),'EFX_MNW_utility_vectors':checked,'EFX_product':best,'global_product':globalbest,'bad_maximizers':bad,'high_vectors':len(self.hs),'winner_counts':self.C[winners[0]].tolist()}
        if top_nonpo:
            ids=np.flatnonzero(fair);order=ids[np.argsort(P[ids])[::-1]];nonpo=None;queries=0;seen=set()
            for k in order:
                u=tuple(map(int,U[k]));
                if u in seen:continue
                seen.add(u);queries+=1;dom=global_dominator(d,u)
                if dom is not None:nonpo={'product':int(P[k]),'class':int(k),'counts':self.C[k].tolist(),'utility':u,'dominator':dom};break
                if queries>=top_nonpo:break
            record.update({'top_nonPO':nonpo,'frontier_queries':queries})
        return record
