"""Exact global MNW and PO via feasible high-count vectors; no low-edge assumption."""
from fractions import Fraction as F
from itertools import combinations,product
import math
import numpy as np

def high_vectors(n,types):
    """Every realizable high-count vector with one witnessing partial assignment."""
    states={(0,)*n:()}
    for t in types:
        nxt={}
        for h,owners in states.items():
            nxt.setdefault(h,owners+(-1,))
            for i in range(n):
                if t>>i&1:
                    new=list(h);new[i]+=1;nxt.setdefault(tuple(new),owners+(i,))
        states=nxt
    return states

def exact_data(n,types,K,ratios):
    rs=list(map(F,ratios));a=np.array([r.numerator for r in rs],dtype=np.int64);b=np.array([r.denominator for r in rs],dtype=np.int64)
    assert all(r>1 for r in rs)
    states=high_vectors(n,types);hs=np.asarray(list(states),dtype=np.int64)
    m=K+len(types);left=m-hs.sum(axis=1);ls=(hs==0).astype(np.int64)
    valid=ls.sum(axis=1)<=left;u=hs*a+ls*b;remaining=left-ls.sum(axis=1)
    for step in range(max(0,int(remaining.max(initial=0)))):
        active=np.flatnonzero(remaining>step)
        if not len(active):break
        chosen=np.zeros(len(active),dtype=np.int64)
        for i in range(1,n):
            better=u[active,i]*b[chosen]<u[active,chosen]*b[i]
            chosen[better]=i
        u[active,chosen]+=b[chosen];ls[active,chosen]+=1
    prods=np.prod(u.astype(object),axis=1);prods[~valid]=0;best=max(prods)
    winners=np.flatnonzero(prods==best)
    return {'n':n,'types':tuple(types),'K':K,'m':m,'a':a,'b':b,'ratios':rs,'states':states,'hs':hs,'base':hs*a,
            'global_product':int(best),'winner_indices':winners,'greedy_lows':ls}

def global_dominator(data,target):
    base=data['base'];b=data['b'];deficits=np.maximum(0,(np.asarray(target)-base+b-1)//b)
    used=data['hs'].sum(axis=1)+deficits.sum(axis=1)
    slack=(base+deficits*b>np.asarray(target)).any(axis=1)
    hit=np.flatnonzero((used<data['m'])|((used==data['m'])&slack))
    if not len(hit):return None
    idx=int(hit[0]);h=tuple(map(int,data['hs'][idx]));l=list(map(int,deficits[idx]));l[0]+=data['m']-int(used[idx])
    ownhigh=data['states'][h];pool=[g for g,o in enumerate(ownhigh) if o<0]+list(range(len(data['types']),data['m']))
    owners=list(ownhigh)+[-1]*data['K'];at=0
    for i,count in enumerate(l):
        for g in pool[at:at+count]:owners[g]=i
        at+=count
    u=literal_utility(data,owners)
    assert all(x>=y for x,y in zip(u,target)) and any(x>y for x,y in zip(u,target))
    return {'owners':owners,'utility':u,'counted_highs':h,'counted_lows':l}

def literal_utility(data,owners):
    ts=list(data['types'])+[0]*data['K']
    return [sum(int(data['a'][i] if ts[g]>>i&1 else data['b'][i]) for g,o in enumerate(owners) if o==i) for i in range(data['n'])]

def literal_envy(data,owners):
    ts=list(data['types'])+[0]*data['K'];u=literal_utility(data,owners);edges=[]
    for i in range(data['n']):
        for j in range(data['n']):
            bundle=[g for g,o in enumerate(owners) if o==j]
            if not bundle:continue
            vals=[int(data['a'][i] if ts[g]>>i&1 else data['b'][i]) for g in bundle]
            if u[i]<sum(vals)-min(vals):edges.append((i,j))
    return edges

def greedy_ties(data,h):
    """All bulk Nash ties for a fixed h; represented by threshold marginal ties."""
    n=data['n'];base=[data['ratios'][i]*h[i] for i in range(n)];L=data['m']-sum(h)
    counts=[int(x==0) for x in base]
    if sum(counts)>L:return
    u=[base[i]+counts[i] for i in range(n)];T=None
    for _ in range(L-sum(counts)):
        i=min(range(n),key=lambda i:(u[i],i));T=u[i];u[i]+=1;counts[i]+=1
    if T is None:
        yield tuple(counts);return
    mandatory=[max(int(base[i]==0),math.ceil(T-base[i])) for i in range(n)]
    optional=[i for i in range(n) if base[i]+mandatory[i]==T]
    r=L-sum(mandatory);assert 0<=r<=len(optional)
    for extra in combinations(optional,r):
        out=mandatory[:]
        for i in extra:out[i]+=1
        assert math.prod(base[i]+out[i] for i in range(n))==math.prod(u)
        yield tuple(out)

def proper_patterns(data):
    choices=[[i for i in range(data['n']) if t>>i&1] for t in data['types']]
    for owners in product(*choices):
        h=tuple(owners.count(i) for i in range(data['n']))
        yield owners,h

def repair_edges(data,owners,h,lows):
    own=[h[i]*int(data['a'][i])+lows[i]*int(data['b'][i]) for i in range(data['n'])];edges=[]
    for i in range(data['n']):
        for j in range(data['n']):
            vals=[int(data['a'][i] if data['types'][g]>>i&1 else data['b'][i]) for g,o in enumerate(owners) if o==j]
            if lows[j]:vals.append(int(data['b'][i]))
            if vals:
                total=sum(vals)+(lows[j]-1)*int(data['b'][i]) if lows[j] else sum(vals)
                if own[i]<total-min(vals):edges.append((i,j))
    return edges,own
