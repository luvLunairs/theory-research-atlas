"""Source-independent, direct labelled verification of the 12-good obstruction.

Only Python standard library. Enumerates all3^12 complete allocations, using
literal single-good-removal residual tables over all2^12 bundles. Global PO
is checked against the complete enumerated utility set, not a high-count oracle.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib,json,math

D=Path(__file__).resolve().parent

def run():
    types=[6,2,7,7]+[0]*7+[4];n=3;m=len(types)
    a=[3,4,29];b=[1,1,10];values=[[a[i] if t>>i&1 else b[i] for t in types] for i in range(n)]
    size=1<<m;U=[[0]*size for _ in range(n)];residual=[[0]*size for _ in range(n)]
    removals=0
    for mask in range(1,size):
        bit=mask&-mask;g=bit.bit_length()-1;prev=mask^bit
        for i in range(n):
            U[i][mask]=U[i][prev]+values[i][g]
            # Literal deletion of every individual good of this bundle.
            residual[i][mask]=max(U[i][mask^(1<<q)] for q in range(m) if mask>>q&1)
            removals+=mask.bit_count()
    allvectors={};fairvectors=Counter();line_signatures=Counter()
    count=0;faircount=0;best=-1;globalbest=-1;best_masks=[];best_vectors=set()
    highmask=sum(1<<g for g,t in enumerate(types) if t>>2&1)
    for owners in product(range(n),repeat=m):
        masks=[0]*n
        for g,i in enumerate(owners):masks[i]|=1<<g
        u=tuple(U[i][masks[i]] for i in range(n));allvectors.setdefault(u,tuple(masks));count+=1
        prod=math.prod(u);globalbest=max(globalbest,prod)
        fair=all(u[i]>=residual[i][masks[j]] for i in range(n) for j in range(n))
        if not fair:continue
        faircount+=1;fairvectors[u]+=1
        h=(masks[2]&highmask).bit_count();l=masks[2].bit_count()-h
        line_signatures[(u[0],u[1],h,l)]+=1
        if prod>best:best=prod;best_masks=[];best_vectors=set()
        if prod==best:best_masks.append(tuple(masks));best_vectors.add(u)
    assert count==3**m and best_vectors=={(8,8,78)}
    # Direct two-dimensional suffix table over the complete utility set.
    umax=max(u[0] for u in allvectors);vmax=max(u[1] for u in allvectors)
    top=[[-1]*(vmax+2) for _ in range(umax+2)]
    for u,v,w in allvectors:top[u][v]=max(top[u][v],w)
    for u in range(umax,-1,-1):
        for v in range(vmax,-1,-1):top[u][v]=max(top[u][v],top[u+1][v],top[u][v+1])
    def dominated(t):
        u,v,w=t
        return top[u][v]>w or top[u+1][v]>=w or top[u][v+1]>=w
    fairpo=sorted(u for u in fairvectors if not dominated(u))
    assert fairpo and all(dominated(u) for u in best_vectors)
    strict=[u for u in allvectors if all(x>=y for x,y in zip(u,(8,8,78))) and u!=(8,8,78)]
    assert (8,8,79) in strict
    bestpo=max(fairpo,key=lambda u:(math.prod(u),u))
    # Symbolic upper-envelope check on gamma∈[26/9,3]. The EFX family is
    # constant throughout (8/3,3), independently proved by the finite row cuts.
    lines=Counter()
    for (ua,ub,h,l),amount in line_signatures.items():lines[(ua*ub*h,ua*ub*l)]+=amount
    endpoint=[]
    for t in [F(26,9),F(3)]:
        target=128*t+128
        assert all(s*t+c<=target for s,c in lines)
        endpoint.append({'gamma':str(t),'maximum_symbolic_EFX_product':str(target),
                         'maximizing_lines':[[s,c] for s,c in sorted(lines) if s*t+c==target]})
    identity=[sig for sig in line_signatures if (sig[0]*sig[1]*sig[2],sig[0]*sig[1]*sig[3])==(128,128)]
    assert identity==[(8,8,2,2)]
    cuts=sorted({F(p,q) for p in range(1,9) for q in range(1,5) if p>q})
    assert not any(F(8,3)<c<3 for c in cuts)
    def owners_from_masks(masks):return [next(i for i in range(n) if masks[i]>>g&1) for g in range(m)]
    out={'status':'PASS','types':types,'row_high_values':a,'row_low_values':b,
         'complete_labelled_allocations':count,'distinct_complete_utility_vectors':len(allvectors),
         'literal_bundle_removal_checks_precomputed':removals,'EFX_labelled_allocations':faircount,
         'EFX_utility_vectors':len(fairvectors),'EFX_PO_utility_vectors':len(fairpo),
         'EFX_Nash_scaled_product':best,'global_Nash_scaled_product':globalbest,
         'EFX_Nash_labelled_allocations':len(best_masks),'EFX_Nash_utility_vectors':[list(x) for x in sorted(best_vectors)],
         'all_EFX_Nash_maximizers_globally_dominated':True,
         'strict_dominator_vectors':strict,
         'EFX_Nash_example_owners':owners_from_masks(best_masks[0]),
         'dominator_example_owners':owners_from_masks(allvectors[(8,8,79)]),
         'EFX_PO_example_utility':bestpo,'EFX_PO_example_owners':owners_from_masks(allvectors[bestpo]),
         'best_EFX_PO_scaled_product':math.prod(bestpo),
         'symbolic_gamma_interval':'(26/9,3)','symbolic_EFX_product_lines':[{'slope':s,'intercept':c,'labelled_allocations':amount} for (s,c),amount in sorted(lines.items())],
         'symbolic_endpoint_bounds':endpoint,'symbolic_maximizer_signatures':identity,
         'EFX_and_PO_C_row_comparison_cuts':list(map(str,cuts)),
         'limits':'A robust failure of the EFX-constrained Nash selector, NOT a counterexample to EFX+PO existence. All complete integral allocations enumerated directly. Symbolic interval uses the stated elementary comparison-cell argument; finite checks are not proof-assistant verification. Local scientific draft; human full-text review and manual submission required.'}
    path=D/'verify-three-agent-nash.json';path.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['symbolic_EFX_product_lines','EFX_and_PO_C_row_comparison_cuts']},indent=2))
    print('SHA256 '+hashlib.sha256(path.read_bytes()).hexdigest())

if __name__=='__main__':run()
