"""Systematic one-guard extension: all256 incidences and all real guard ratios.

The three old ratios are fixed3,4,29/10. Every guard may like any of five old
exceptional goods; its new high good may also be high to any old-agent subset.
Seven universal lows remain. Every witness is checked for EFX and globalPO.
"""
from search_guarded_nash import Grouped,F,D,EXPECTED
from search_existence_guards import evaluate
from exhaust_candidate_ratio_cells import cells
from high_vector_exact import high_vectors,global_dominator
from itertools import product
from collections import Counter
import hashlib,json,time
import numpy as np

def run():
    counts=[1,1,1,1,7,1,1];s=Grouped(4,counts)
    pool=[];poolset=set();witnesses=[];witnessindex={};cases=[];stats=Counter();failure=None;start=time.monotonic()
    def retain(w):
        key=tuple(map(tuple,w))
        if key not in poolset:poolset.add(key);pool.append(key)
        if key not in witnessindex:witnessindex[key]=len(witnesses);witnesses.append(key)
        return witnessindex[key]
    for guard_likes in range(32):
        for old_likes_new in range(8):
            base=[6,2,7,7,0,4,8|old_likes_new];oldslots=[0,1,2,3,5]
            for j,pos in enumerate(oldslots):
                if guard_likes>>j&1:base[pos]|=8
            types=base;nonzero=[t for t,c in zip(types,counts) for _ in range(c) if t]
            states=high_vectors(4,nonzero);hs=np.asarray(list(states),dtype=np.int64)
            H=1+guard_likes.bit_count();grid=cells(H,13-H);ids=[];last=None
            for cell in grid:
                ratios=[F(3),F(4),F(29,10),F(cell['sample'])]
                a=np.array([r.numerator for r in ratios],dtype=np.int64);b=np.array([r.denominator for r in ratios],dtype=np.int64)
                data={'n':4,'types':nonzero,'K':7,'m':13,'a':a,'b':b,'ratios':ratios,'states':states,'hs':hs,'base':hs*a}
                values=[[int(a[i] if t>>i&1 else b[i]) for t in types] for i in range(4)]
                def acceptable(w):
                    stats['cached_witness_attempts']+=1
                    own=[sum(w[t][i]*values[i][t] for t in range(7)) for i in range(4)]
                    for i,j in product(range(4),repeat=2):
                        if i==j:continue
                        items=[values[i][t] for t in range(7) if w[t][j]]
                        if items and own[i]<sum(w[t][j]*values[i][t] for t in range(7))-min(items):return False
                    stats['cached_global_PO_queries']+=1
                    return global_dominator(data,own) is None
                found=None
                candidates=([last] if last is not None else [])+list(reversed(pool[-96:]))
                for w in candidates:
                    if acceptable(w):found=w;break
                if found is None:
                    result=evaluate(s,types,ratios);stats['full_profile_enumerations']+=1;stats['complete_grouped_classes']+=s.classes;stats['fallback_global_PO_queries']+=result['global_PO_queries']
                    if result['best_EFX_PO'] is None:
                        failure={'guard_likes':guard_likes,'old_likes_new':old_likes_new,'cell':cell,'result':result};break
                    found=tuple(map(tuple,result['best_EFX_PO']['counts']));assert acceptable(found)
                ids.append(retain(found));last=found;stats['ratio_cells']+=1
            if failure:break
            cases.append({'guard_high_subset_of_five_old_goods':guard_likes,'old_agent_subset_liking_new_good':old_likes_new,
                          'types':types,'guard_high_degree':H,'guard_ratio_cells':grid,'witness_ids':ids})
        if failure:break
        print(json.dumps({'incidence_profiles':len(cases),'cells':stats['ratio_cells'],'full_enumerations':stats['full_profile_enumerations'],'witnesses':len(witnesses),'seconds':round(time.monotonic()-start,3)}),flush=True)
    out={'status':'PASS' if failure is None and len(cases)==256 else 'CANDIDATE_COUNTEREXAMPLE',
         'n':4,'m':13,'fixed_old_agent_ratios':['3','4','29/10'],'counts':counts,
         'stats':dict(stats),'incidence_profiles':len(cases),'cases':cases,'witnesses':witnesses,
         'counterexample':failure,'source_hashes':EXPECTED,'seconds':time.monotonic()-start,
         'claim':'Every one-agent/one-good guard extension in the defined256 labelled incidence profiles has complete EFX+global integral PO for every real guard ratio>1.',
         'limits':'Some incidences are isomorphic under swapping the two original universal-high goods. This is a finite incidence family with one unrestricted ratio, not unrestricted existence. Each retained witness globalPO uses the exact high-count resource oracle; independent replay still required. Local draft; full-text human review and manual submission required.'}
    path=D/'all-one-guard-family.json';path.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['cases','witnesses']},indent=2))

if __name__=='__main__':run()
