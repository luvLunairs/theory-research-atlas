"""Guard extensions of the n3 EFX-Nash obstruction; exact existence queries.

Search prefers a large product gap between best EFX and best EFX+globalPO.
If no EFX+PO allocation remains, EVERY EFX utility vector has been queried.
Scores and profiles are heuristic; each existence result is exact.
"""
from search_guarded_nash import Grouped,F,D,EXPECTED
from high_vector_exact import global_dominator
from itertools import product
from collections import Counter
import argparse,json,math,random,time
import numpy as np

def evaluate(s,types,ratios):
    rs=list(map(F,ratios));s.set_types(types)
    a=np.asarray([x.numerator for x in rs],dtype=np.int64);b=np.asarray([x.denominator for x in rs],dtype=np.int64)
    U=np.stack([b[i]*s.S[:,i]+(a[i]-b[i])*s.H[i,:,i] for i in range(s.n)],axis=1)
    assert math.prod(map(int,U.max(axis=0)))<2**63
    fair=np.ones(s.classes,dtype=bool)
    for i,j in product(range(s.n),repeat=2):
        if i==j:continue
        minimum=np.where(s.H[i,:,j]<s.S[:,j],b[i],a[i])
        fair&=U[:,i]>=b[i]*s.S[:,j]+(a[i]-b[i])*s.H[i,:,j]-minimum
    assert fair.any();P=U.prod(axis=1);ids=np.flatnonzero(fair);order=ids[np.argsort(P[ids])[::-1]];d=s.data(rs)
    seen={};dominators=[];po=None;queries=0
    for k in order:
        u=tuple(map(int,U[k]))
        if u in seen:continue
        dom=global_dominator(d,u);seen[u]=dom;queries+=1
        if dom is None:
            po={'class':int(k),'counts':s.C[k].tolist(),'utility':u,'product':int(P[k])};break
        if len(dominators)<10:dominators.append({'class':int(k),'utility':u,'product':int(P[k]),'dominator':dom})
    return {'types':list(types),'counts':s.counts,'ratios':list(map(str,rs)),
            'EFX_classes':len(ids),'best_EFX_product':int(P[order[0]]),
            'best_EFX_class':int(order[0]),'best_EFX_counts':s.C[order[0]].tolist(),
            'best_EFX_PO':po,'global_PO_queries':queries,'leading_dominated_EFX_vectors':dominators,
            'all_EFX_utility_vectors_excluded':po is None}

def run(args):
    rng=random.Random(args.seed);counts=list(map(int,args.counts.split(',')));s=Grouped(4,counts)
    assert len(counts)==6
    pool=sorted({F(p,q) for q in range(1,11) for p in range(q+1,min(15*q,70)+1)}|{F(20),F(30),F(50)})
    initial=(tuple([6,2,7,0,4,args.guard_type]),tuple([F(3),F(4),F(29,10),F(args.guard_ratio)]))
    state=initial;best=None;current=None;stats=Counter();profiles=[];events=[];failure=None;start=time.monotonic()
    for step in range(args.steps):
        restart=step%60==0
        if restart:
            state=best[1] if best and rng.random()<.7 else initial
            if step and rng.random()<.3:
                types=list(state[0]);types[5]=rng.choice([9,10,11,12,13,14,15]);state=(tuple(types),state[1])
        else:
            oldstate=state;types=list(state[0]);rs=list(state[1])
            if rng.random()<.85:
                i=rng.randrange(4);near=[r for r in pool if .8<float(r/rs[i])<1.25]
                rs[i]=rng.choice(near if near and rng.random()<.85 else pool)
            else:
                g=rng.choice([0,1,2,4,5]);i=3 if rng.random()<.6 else rng.randrange(4);types[g]^=1<<i
            state=(tuple(types),tuple(rs))
        r=evaluate(s,*state);profiles.append(r);stats['profile_evaluations']+=1;stats['complete_grouped_classes']+=s.classes
        stats['EFX_classes']+=r['EFX_classes'];stats['global_PO_queries']+=r['global_PO_queries']
        if r['best_EFX_PO'] is None:
            failure=r;break
        score=math.log(r['best_EFX_product']/r['best_EFX_PO']['product'])
        if score>0:stats['profiles_with_all_Nash_maxima_dominated']+=1
        if best is None or score>best[0]:best=(score,state,r);events.append({'step':step,'score':score,'result':r})
        if restart or current is None:current=score
        else:
            temp=.015*(1-step%60/60)+.0002
            if score>=current or rng.random()<math.exp(max(-700,(score-current)/temp)):current=score
            else:state=oldstate
        if (step+1)%20==0:print(json.dumps({'step':step+1,'best_log_gap':best[0],'seconds':round(time.monotonic()-start,3),'queries':stats['global_PO_queries']}),flush=True)
    out={'parameters':vars(args),'source_hashes':EXPECTED,'stats':dict(stats),'counterexample':failure,
         'improving_events':events,'profiles':profiles,'seconds':time.monotonic()-start,
         'limits':'All complete allocations represented by exact identical-good count classes. Every retained best EFX+PO result is globally PO and optimal in product among EFX+PO. Existence failure requires exhaustively rejecting every EFX utility vector; heuristic mutation alone proves nothing. Local scientific draft; human full-text review and manual submission required.'}
    (D/args.output).write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['profiles','improving_events']},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--counts',default='1,1,2,13,1,1');p.add_argument('--steps',type=int,default=240)
    p.add_argument('--guard-type',type=int,default=9);p.add_argument('--guard-ratio',default='5')
    p.add_argument('--seed',type=int,default=204803);p.add_argument('--output',default='existence-guards-n4m19.json');run(p.parse_args())
