"""Independent literal EFX and complete-core PO check of the 500 witnesses."""
from pathlib import Path
from itertools import product
from fractions import Fraction as F
import hashlib,json
import numpy as np

D=Path(__file__).resolve().parent

def run():
    path=D/'two-guards-n5m14.json';data=json.loads(path.read_text())
    assert data['status']=='PASS' and len(data['profiles'])==data['parameters']['profiles']
    n=5;G=7;K=7;coremaps=np.asarray(list(product(range(n),repeat=G)),dtype=np.int8)
    positions=[(coremaps==i).astype(np.int64) for i in range(n)]
    checks=0;profiles=0
    for case in data['profiles']:
        assert case['status']=='EFX_PO_WITNESS';types=case['types'];assert len(types)==G and all(0<t<1<<n for t in types)
        ratios=list(map(F,case['ratios']));assert len(ratios)==n and all(r>1 for r in ratios)
        a=np.array([r.numerator for r in ratios],dtype=np.int64);b=np.array([r.denominator for r in ratios],dtype=np.int64)
        witness=case['witness'];owners=witness['high_owners'];lows=witness['universal_lows']
        assert len(owners)==G and all(isinstance(i,int) and 0<=i<n for i in owners)
        assert len(lows)==n and all(isinstance(x,int) and x>=0 for x in lows) and sum(lows)==K
        fullown=owners+[i for i,c in enumerate(lows) for _ in range(c)];fulltypes=types+[0]*K
        values=[[int(a[i] if t>>i&1 else b[i]) for t in fulltypes] for i in range(n)]
        target=np.array([sum(values[i][g] for g,o in enumerate(fullown) if o==i) for i in range(n)],dtype=np.int64)
        assert tuple(map(int,target))==tuple(witness['scaled_utilities'])
        for i,j in product(range(n),repeat=2):
            bundle=[g for g,o in enumerate(fullown) if o==j]
            for removed in bundle:
                checks+=1;assert target[i]>=sum(values[i][g] for g in bundle if g!=removed)
        W=np.stack([positions[i]@np.array(values[i][:G],dtype=np.int64) for i in range(n)],axis=1)
        need=np.maximum(0,(target-W+b-1)//b);s=need.sum(axis=1);gain=(W+need*b>target).any(axis=1)
        assert not ((s<K)|((s==K)&gain)).any(),profiles
        profiles+=1
    result={'status':'PASS','search_output_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'profiles':profiles,'literal_single_good_removal_checks':checks,
            'complete_exceptional_owner_maps_per_profile':len(coremaps),
            'complete_core_compensation_comparisons':profiles*len(coremaps),
            'dependencies':'Python standard library and NumPy only; no project solver imports.',
            'scope':'Every retained sampled two-guard witness is complete EFX and globally integral PO. All actual exceptional-owner maps, including low-valuing holders, are checked; exact universal-low deficits cover all remaining assignments. No all-incidence or all-ratio claim.'}
    (D/'verify-two-guards.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':run()
