"""Exact grouped EFX-Nash search near the v6 three-agent ascent obstruction.

Every evaluated profile represents ALL complete ownership allocations by
identical-good count classes. All EFX Nash maximizing utility vectors receive
the unrestricted high-count global-PO query. Search scoring is heuristic only.
New outputs only; preceding solver versions are bound by SHA256.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import argparse, hashlib, json, math, os, random, sys, time

D=Path(__file__).resolve().parent
OLD=Path(os.environ.get('QMODEL204_V6_SEARCH',str(D.parent/'qmodel204-v6-search')))
if not OLD.is_dir():
    for ancestor in D.parents:
        if (ancestor/'CONTRIBUTING.md').is_file():
            OLD=ancestor/'work'/'qmodel204-v6-search';break
EXPECTED={'high_vector_exact.py':'8b332f827965f2661ea501d01567cfd7873522b8edcfaf2a32bc089b589dd213',
          'grouped_exact.py':'56afaea6d2af90819f44f5dcf5c8aa4585c62dde7b643e7cd1e2bde869502ffc'}
for name,want in EXPECTED.items():
    assert hashlib.sha256((OLD/name).read_bytes()).hexdigest()==want
sys.path.insert(0,str(OLD))
from grouped_exact import Grouped

def run(args):
    rng=random.Random(args.seed);counts=list(map(int,args.counts.split(',')))
    solver=Grouped(args.n,counts);start=time.monotonic();stats=Counter()
    pool=sorted({F(p,q) for q in range(1,10) for p in range(q+1,min(20*q,80)+1)}|{F(30),F(50),F(100)})
    if args.n==4:
        starts=[(6,14,5,0,8),(14,6,13,0,8),(6,6,13,0,8),(14,14,13,0,8)]
    else:
        starts=[(6,14,21,0,8,16),(14,22,29,0,8,16),(30,6,5,0,8,16)]
    assert len(counts)==len(starts[0])
    state=None;current=None;best=None;records=[];events=[];failure=None
    for step in range(args.steps):
        restart=(step%80==0)
        if restart:
            if best and rng.random()<.55:
                state=best[1]
            else:
                rs=[F(3),F(8,3),rng.choice([F(4),F(8),F(20),F(50)])]+[rng.choice(pool) for _ in range(args.n-3)]
                state=(rng.choice(starts),tuple(rs))
        else:
            oldstate=state;types=list(state[0]);rs=list(state[1])
            if rng.random()<.88:
                i=rng.randrange(args.n);near=[x for x in pool if .75<float(x/rs[i])<1.33]
                rs[i]=rng.choice(near if near and rng.random()<.8 else pool)
            else:
                g=rng.choice([0,1,2,4]+([5] if args.n==5 else []))
                # Primarily change guard overlap, with occasional full profile mutation.
                i=rng.randrange(3,args.n) if rng.random()<.8 else rng.randrange(args.n)
                types[g]^=1<<i
            state=(tuple(types),tuple(rs))
        result=solver.evaluate(state[0],state[1],top_nonpo=args.frontier)
        record={'step':step,'result':result};records.append(record)
        stats['profile_evaluations']+=1;stats['complete_grouped_classes']+=solver.classes
        stats['EFX_classes']+=result['EFX_classes'];stats['EFX_Nash_vectors_checked']+=result['EFX_MNW_utility_vectors']
        stats['frontier_global_PO_queries']+=result['frontier_queries']
        nonpo=result['top_nonPO'];score=math.log(nonpo['product']/result['EFX_product']) if nonpo else -10.0
        if best is None or score>best[0]:
            best=(score,state,result);events.append({'step':step,'score':score,'result':result})
        if result['bad_maximizers']:
            failure={'kind':'dominated_EFX_Nash_maximum_NOT_YET_existence_counterexample','record':record};break
        if restart or current is None:current=score
        else:
            temp=.04*(1-step%80/80)+.001
            if score>=current or rng.random()<math.exp(max(-700,(score-current)/temp)):current=score
            else:state=oldstate
        if (step+1)%40==0:
            print(json.dumps({'step':step+1,'seconds':round(time.monotonic()-start,3),'best_score':best[0],
                              'unique_profiles':len({(tuple(x['result']['types']),tuple(x['result']['ratios'])) for x in records})}),flush=True)
    out={'parameters':vars(args),'source_hashes':{name:hashlib.sha256((OLD/name).read_bytes()).hexdigest() for name in ['high_vector_exact.py','grouped_exact.py']},
         'stats':dict(stats),'distinct_profiles':len({(tuple(x['result']['types']),tuple(x['result']['ratios'])) for x in records}),
         'failure':failure,'improving_events':events,'profiles':records,
         'seconds':time.monotonic()-start,
         'limits':'Exact EFX and global integral PO queries on every EFX Nash maximizing utility vector of each evaluated profile. Revisits allowed; counts are quotient count classes, not independently labelled allocations. Highest-nonPO scoring checks only a bounded frontier. A method obstruction alone is not an existence counterexample. Local scientific draft; human full-text review and manual submission required.'}
    (D/args.output).write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['profiles','improving_events']},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,choices=[4,5],default=4)
    p.add_argument('--counts',default='3,1,2,7,1');p.add_argument('--steps',type=int,default=600)
    p.add_argument('--frontier',type=int,default=40);p.add_argument('--seed',type=int,default=204801)
    p.add_argument('--output',default='guarded-n4-first.json');run(p.parse_args())
