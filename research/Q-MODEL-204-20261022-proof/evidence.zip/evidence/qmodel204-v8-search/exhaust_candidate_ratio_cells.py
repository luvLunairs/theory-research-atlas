"""All-ratio EFX+PO existence certificate for the new 12-good incidence family.

The agent-specific comparison-cell argument is from the retained v4/v7 work.
Nash ranking is NOT claimed constant inside cells. Each retained witness has
literal EFX and global integral PO throughout its cell, which are constant.
"""
from search_guarded_nash import Grouped,F,D,EXPECTED,OLD
from itertools import product
from collections import Counter
import hashlib,json,math,time
import numpy as np
from high_vector_exact import global_dominator

def cells(H,L):
    if not H or not L:return [{'kind':'irrelevant','sample':'2'}]
    cuts=sorted({F(p,q) for p in range(1,L+1) for q in range(1,H+1) if p>q})
    result=[];left=F(1)
    for right in cuts:
        result.extend([{'kind':'open','left':str(left),'right':str(right),'sample':str((left+right)/2)},
                       {'kind':'point','sample':str(right)}]);left=right
    result.append({'kind':'open','left':str(left),'right':None,'sample':str(left+1)})
    return result

def run():
    n=3;types=[6,2,7,0,4];counts=[1,1,2,7,1];s=Grouped(n,counts);s.set_types(types)
    H=[sum(c for t,c in zip(types,counts) if t>>i&1) for i in range(n)]
    grids=[cells(h,s.m-h) for h in H];stats=Counter();witness_map={};witness_ids=[];failures=[];counter=None
    start=time.monotonic();cell_count=math.prod(map(len,grids))
    for index,cs in enumerate(product(*grids)):
        rs=list(map(lambda c:F(c['sample']),cs));a=np.asarray([x.numerator for x in rs],dtype=np.int64);b=np.asarray([x.denominator for x in rs],dtype=np.int64)
        U=np.stack([b[i]*s.S[:,i]+(a[i]-b[i])*s.H[i,:,i] for i in range(n)],axis=1)
        fair=np.ones(s.classes,dtype=bool)
        for i,j in product(range(n),repeat=2):
            if i==j:continue
            minimum=np.where(s.H[i,:,j]<s.S[:,j],b[i],a[i])
            fair&=U[:,i]>=b[i]*s.S[:,j]+(a[i]-b[i])*s.H[i,:,j]-minimum
        assert fair.any();P=U.prod(axis=1);ids=np.flatnonzero(fair);order=ids[np.argsort(P[ids])[::-1]]
        d=s.data(rs);cache={};maxP=int(P[order[0]]);bad_top=[];found=None
        for at,k in enumerate(order):
            u=tuple(map(int,U[k]));prod=int(P[k])
            if u not in cache:
                cache[u]=global_dominator(d,u);stats['global_PO_queries']+=1
            dom=cache[u]
            if prod==maxP:
                if dom is not None:bad_top.append(int(k))
                stats['Nash_maximizer_class_tests']+=1
            if dom is None and found is None:found=int(k)
            # Finish all maximizing classes, then stop once one globalPO exists.
            if found is not None and (at+1==len(order) or int(P[order[at+1]])<maxP):break
        if found is None:
            counter={'cell_index':index,'ratios':list(map(str,rs)),'EFX_classes':len(ids)};break
        if bad_top:
            stats['cells_with_dominated_Nash_maximizers_at_sample']+=1
            if len(failures)<50:failures.append({'cell_index':index,'ratios':list(map(str,rs)),
                'all_Nash_maximizers_dominated_at_sample':int(P[found])<maxP,
                'dominated_class':bad_top[0],'EFX_PO_class':found})
            if int(P[found])<maxP:stats['cells_all_Nash_maximizers_dominated_at_sample']+=1
        if found not in witness_map:witness_map[found]=len(witness_map)
        witness_ids.append(witness_map[found]);stats['ratio_cells']+=1;stats['complete_grouped_classes']+=s.classes;stats['EFX_classes']+=len(ids)
        if (index+1)%2000==0:print(json.dumps({'cell':index+1,'total':cell_count,'seconds':round(time.monotonic()-start,3),'witnesses':len(witness_map),'method_failure_cells':stats['cells_all_Nash_maximizers_dominated_at_sample']}),flush=True)
    out={'status':'PASS' if counter is None and len(witness_ids)==cell_count else 'CANDIDATE_COUNTEREXAMPLE',
         'n':n,'types':types,'counts':counts,'high_degrees':H,'ratios_by_agent_cells':grids,
         'total_ratio_cells':cell_count,'stats':dict(stats),'counterexample':counter,
         'witness_classes':[{'class':k,'counts':s.C[k].tolist()} for k,v in sorted(witness_map.items(),key=lambda p:p[1])],
         'cell_witness_ids':witness_ids,'method_failure_sample_examples':failures,
         'source_hashes':EXPECTED,'seconds':time.monotonic()-start,
         'claim':'For every real row ratio>1 on this fixed12-good incidence family, a complete EFX and globally integral Pareto-optimal allocation exists, certified by the retained cell witness.',
         'cell_order':'Cartesian product of per-agent lists, last coordinate varying fastest. Singleton boundaries, open intervals, and unbounded tail all included.',
         'limits':'Nash ranking is not cell constant; method-failure counts concern exact sample ratios only. Witness existence uses the elementary ratio-cell sign theorem from retained v4/v7 work. Ordinary exact computational certificate, not formal verification. Local draft requiring full-text human review and manual submission.'}
    path=D/'candidate-all-ratio-cells.json';path.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['ratios_by_agent_cells','witness_classes','cell_witness_ids','method_failure_sample_examples']},indent=2))

if __name__=='__main__':run()
