"""Independent direct complete-core verification of all one-guard certificates.

Enumerates all4^6 actual exceptional-good owner maps; universal-low deficits
are exact. Imports no project solver. Uses mediants and a different tail sample.
"""
from pathlib import Path
from itertools import product
from fractions import Fraction as F
import hashlib,json
import numpy as np

D=Path(__file__).resolve().parent

def run():
    path=D/'all-one-guard-family.json';cert=json.loads(path.read_text())
    assert cert['status']=='PASS' and cert['n']==4 and cert['m']==13
    assert cert['fixed_old_agent_ratios']==['3','4','29/10']
    counts=[1,1,1,1,7,1,1];assert cert['counts']==counts
    assert len(cert['cases'])==256
    pairs={(c['guard_high_subset_of_five_old_goods'],c['old_agent_subset_liking_new_good']) for c in cert['cases']}
    assert pairs==set(product(range(32),range(8)))
    coreowners=np.array(list(product(range(4),repeat=6)),dtype=np.int8)
    sizes=np.stack([(coreowners==i).sum(axis=1) for i in range(4)],axis=1)
    checks=0;cells=0
    for case in cert['cases']:
        guardbits=case['guard_high_subset_of_five_old_goods'];oldbits=case['old_agent_subset_liking_new_good']
        types=[6,2,7,7,0,4,8|oldbits]
        for bit,pos in enumerate([0,1,2,3,5]):
            if guardbits>>bit&1:types[pos]|=8
        assert types==case['types'];H=1+guardbits.bit_count();L=13-H
        cuts=sorted({F(p,q) for q in range(1,H+1) for p in range(q+1,L+1)})
        grid=[];left=F(1)
        for right in cuts:
            grid.extend([('open',left,right,F(left.numerator+right.numerator,left.denominator+right.denominator)),('point',right,right,right)]);left=right
        grid.append(('open',left,None,left+2));assert len(grid)==len(case['guard_ratio_cells'])==len(case['witness_ids'])
        core=[t for t in types if t];assert len(core)==6
        high=np.stack([((coreowners==i)*np.array([bool(t>>i&1) for t in core])).sum(axis=1) for i in range(4)],axis=1)
        low=sizes-high
        expanded=[t for t,c in zip(types,counts) for _ in range(c)]
        for j,(kind,left,right,sample) in enumerate(grid):
            declared=case['guard_ratio_cells'][j];assert declared['kind']==kind
            if kind=='point':assert F(declared['sample'])==sample
            else:assert F(declared['left'])==left and (None if declared['right'] is None else F(declared['right']))==right
            rs=[F(3),F(4),F(29,10),sample];a=np.array([r.numerator for r in rs],dtype=np.int64);b=np.array([r.denominator for r in rs],dtype=np.int64)
            wid=case['witness_ids'][j];assert 0<=wid<len(cert['witnesses']);rows=cert['witnesses'][wid]
            assert len(rows)==7 and all(len(row)==4 and all(isinstance(x,int) and x>=0 for x in row) and sum(row)==c for row,c in zip(rows,counts))
            own=[i for row in rows for i,c in enumerate(row) for _ in range(c)]
            values=[[int(a[i] if t>>i&1 else b[i]) for t in expanded] for i in range(4)]
            target=np.array([sum(values[i][g] for g,o in enumerate(own) if o==i) for i in range(4)],dtype=np.int64)
            for i,k in product(range(4),repeat=2):
                bundle=[g for g,o in enumerate(own) if o==k]
                for removed in bundle:
                    checks+=1;assert target[i]>=sum(values[i][g] for g in bundle if g!=removed)
            W=high*a+low*b
            need=np.maximum(0,(target-W+b-1)//b);minimum=need.sum(axis=1)
            strict=(W+need*b>target).any(axis=1)
            assert not ((minimum<7)|((minimum==7)&strict)).any(),(guardbits,oldbits,j)
            cells+=1
    out={'status':'PASS','certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
         'incidence_profiles':len(cert['cases']),'ratio_cells':cells,'witness_count':len(cert['witnesses']),
         'literal_single_good_removal_checks':checks,'complete_exceptional_owner_maps_per_cell':len(coreowners),
         'complete_core_compensation_comparisons':cells*len(coreowners),
         'independence':'No project solver imports. Every actual complete exceptional-owner map is enumerated, including low-valuing owners. Exact universal-low ceiling deficits test all complete allocations. Interior cell representatives are mediants, and tail samples use lower endpoint+2.',
         'scope':'All256 labelled one-guard incidence profiles at fixed old ratios3,4,29/10 and every real guard ratio>1. The general unrestricted existence question is not settled.'}
    (D/'verify-one-guard-family.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

if __name__=='__main__':run()
