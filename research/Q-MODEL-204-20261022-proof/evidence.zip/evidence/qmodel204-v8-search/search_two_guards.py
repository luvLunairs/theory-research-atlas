"""Bounded exact two-guard search with COMPLETE fallback before any counterclaim.

Try all high-held exceptional cores first. A missing witness triggers all5^7
actual exceptional owner maps, with all330 low distributions. Global dominance
always uses the unrestricted integral oracle. A found witness stops a profile.
"""
from search_guarded_nash import F,D,EXPECTED
from high_vector_exact import high_vectors,global_dominator
from itertools import product
from collections import Counter
import argparse,json,math,random,time
import numpy as np

def low_vectors(K,n):
    if n==1:yield (K,);return
    for x in range(K+1):
        for rest in low_vectors(K-x,n-1):yield (x,)+rest

def profile(types,rs):
    n=5;G=len(types);K=7;m=G+K
    a=np.array([r.numerator for r in rs],dtype=np.int64);b=np.array([r.denominator for r in rs],dtype=np.int64)
    assert math.prod(int(m*x) for x in a)<2**63
    states=high_vectors(n,types);hs=np.asarray(list(states),dtype=np.int64)
    data={'n':n,'types':types,'K':K,'m':m,'a':a,'b':b,'ratios':rs,'states':states,'hs':hs,'base':hs*a}
    baseline=[2*rs[0],2*rs[1],rs[2],rs[3],rs[4]]
    pools=list(low_vectors(K,n));mean=(sum(baseline)+K)/n
    pools.sort(key=lambda l:(sum((baseline[i]+l[i]-mean)**2 for i in range(n)),l))
    stats=Counter();seen=set();attempts=[]
    for mode in ['proper','complete']:
        choices=[[i for i in range(n) if t>>i&1] for t in types] if mode=='proper' else [range(n)]*G
        owners=np.asarray(list(product(*choices)),dtype=np.int8)
        sizes=np.stack([(owners==i).sum(axis=1) for i in range(n)],axis=1)
        H=np.stack([np.stack([((owners==j)*np.array([bool(t>>i&1) for t in types])).sum(axis=1) for j in range(n)],axis=1) for i in range(n)])
        base=np.stack([b[i]*sizes[:,i]+(a[i]-b[i])*H[i,:,i] for i in range(n)],axis=1)
        for lows in pools:
            L=np.asarray(lows,dtype=np.int64);U=base+L*b;fair=np.ones(len(owners),dtype=bool)
            stats[mode+'_core_bulk_classes_tested']+=len(owners);stats[mode+'_bulk_vectors_visited']+=1
            for i,j in product(range(n),repeat=2):
                if i==j:continue
                minimum=np.where((H[i,:,j]<sizes[:,j])|(L[j]>0),b[i],a[i])
                fair&=U[:,i]>=b[i]*(sizes[:,j]+L[j])+(a[i]-b[i])*H[i,:,j]-minimum
            ids=np.flatnonzero(fair);stats[mode+'_EFX_classes_found']+=len(ids)
            if not len(ids):continue
            P=U[ids].prod(axis=1)
            for k in ids[np.argsort(P)[::-1]]:
                u=tuple(map(int,U[k]))
                if u in seen:continue
                seen.add(u);stats['global_PO_queries']+=1
                dom=global_dominator(data,u)
                if dom is None:
                    return {'types':types,'ratios':list(map(str,rs)),'status':'EFX_PO_WITNESS','stats':dict(stats),
                            'witness':{'high_owners':list(map(int,owners[k])),'universal_lows':lows,'scaled_utilities':u},
                            'search_mode_at_success':mode,'proper_core_count':math.prod([sum(bool(t>>i&1) for i in range(n)) for t in types]),
                            'global_high_count_states':len(states)}
                if len(attempts)<10:attempts.append({'utility':u,'dominator':dom})
        if mode=='proper':stats['complete_fallbacks']+=1
    return {'types':types,'ratios':list(map(str,rs)),'status':'CANDIDATE_NO_EFX_PO','stats':dict(stats),
            'all_EFX_utility_vectors_excluded':len(seen),'sample_dominators':attempts}

def run(args):
    rng=random.Random(args.seed);out=[];stats=Counter();start=time.monotonic()
    ratios=[F(3,2),F(2),F(5,2),F(29,10),F(3),F(10,3),F(4),F(5),F(6),F(8),F(10),F(15)]
    for index in range(args.profiles):
        types=[6,2,7,7,4,8,16]
        for pos in range(5):
            if rng.randrange(2):types[pos]|=8
            if rng.randrange(2):types[pos]|=16
        types[5]|=rng.randrange(8);types[6]|=rng.randrange(8)
        if rng.randrange(2):types[5]|=16
        if rng.randrange(2):types[6]|=8
        rs=[F(3),F(4),F(29,10),rng.choice(ratios),rng.choice(ratios)]
        if index%3==2:
            j=rng.randrange(3);rs[j]=rng.choice(ratios)
        z=profile(types,rs);out.append(z)
        for key,value in z['stats'].items():stats[key]+=value
        stats['profiles']+=1
        if z['status']!='EFX_PO_WITNESS':break
        if (index+1)%50==0:print(json.dumps({'profiles':index+1,'stats':dict(stats),'seconds':round(time.monotonic()-start,3)}),flush=True)
    result={'parameters':vars(args),'source_hashes':EXPECTED,'stats':dict(stats),'profiles':out,
            'status':'PASS' if all(z['status']=='EFX_PO_WITNESS' for z in out) else 'CANDIDATE_COUNTEREXAMPLE',
            'seconds':time.monotonic()-start,
            'scope':'Sampled n5,m14 two-guard extensions. Each PASS profile has an exact complete EFX+global integral PO witness. Proper-core search alone is never treated as an existence refutation; all5^7 complete cores and330 low vectors are mandatory fallback before a counterclaim. No all-ratio or all-incidence claim.'}
    (D/args.output).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='profiles'},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--profiles',type=int,default=500);p.add_argument('--seed',type=int,default=204805)
    p.add_argument('--output',default='two-guards-n5m14.json');run(p.parse_args())
