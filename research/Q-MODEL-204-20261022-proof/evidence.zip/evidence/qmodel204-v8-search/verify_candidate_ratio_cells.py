"""Independent all-ratio certificate replay, without project solver imports.

Uses every3^5 labelled exceptional ownership map and every36 universal-low
distribution, including low-held exceptional goods. Cell interiors are replayed
at mediants, different from the builder's midpoint representatives.
"""
from pathlib import Path
from itertools import product
from fractions import Fraction as F
import hashlib,json,math
import numpy as np

D=Path(__file__).resolve().parent

def run():
    path=D/'candidate-all-ratio-cells.json';cert=json.loads(path.read_text())
    assert cert['status']=='PASS' and cert['n']==3
    assert cert['types']==[6,2,7,0,4] and cert['counts']==[1,1,2,7,1]
    expanded=[t for t,c in zip(cert['types'],cert['counts']) for _ in range(c)]
    core=[t for t in expanded if t];n=3;m=len(expanded);K=expanded.count(0)
    # Deliberately over-refined labelled-core enumeration, independent of the
    # builder's identical-column count quotient and high-vector dominance.
    hs=[];ls=[]
    for own in product(range(n),repeat=len(core)):
        hh=[sum(o==i and bool(t>>i&1) for t,o in zip(core,own)) for i in range(n)]
        ll=[own.count(i)-hh[i] for i in range(n)]
        for x in range(K+1):
            for y in range(K-x+1):
                bulk=(x,y,K-x-y);hs.append(hh);ls.append([ll[i]+bulk[i] for i in range(n)])
    hs=np.asarray(hs,dtype=np.int64);ls=np.asarray(ls,dtype=np.int64)
    assert len(hs)==3**5*36==8748
    grids=[]
    for i in range(n):
        H=sum(bool(t>>i&1) for t in expanded);L=m-H
        cuts=sorted({F(p,q) for q in range(1,H+1) for p in range(q+1,L+1)})
        grid=[];left=F(1)
        for right in cuts:
            grid.extend([('open',left,right,F(left.numerator+right.numerator,left.denominator+right.denominator)),
                         ('point',right,right,right)]);left=right
        grid.append(('open',left,None,left+2));grids.append(grid)
        declared=cert['ratios_by_agent_cells'][i];assert len(declared)==len(grid)
        for a,b in zip(declared,grid):
            assert a['kind']==b[0]
            if b[0]=='point':assert F(a['sample'])==b[3]
            else:assert F(a['left'])==b[1] and (None if a['right'] is None else F(a['right']))==b[2]
    assert len(cert['cell_witness_ids'])==math.prod(map(len,grids))==cert['total_ratio_cells']
    witnesses=[]
    for w in cert['witness_classes']:
        counts=w['counts'];assert len(counts)==len(cert['types'])
        assert all(len(row)==n and all(isinstance(x,int) and x>=0 for x in row) and sum(row)==c for row,c in zip(counts,cert['counts']))
        own=[i for row in counts for i,c in enumerate(row) for _ in range(c)]
        witnesses.append(own)
    checks=0;cellcount=0
    for index,cs in enumerate(product(*grids)):
        rs=[c[3] for c in cs];a=np.array([r.numerator for r in rs],dtype=np.int64);b=np.array([r.denominator for r in rs],dtype=np.int64)
        wid=cert['cell_witness_ids'][index];assert 0<=wid<len(witnesses);own=witnesses[wid]
        values=[[int(a[i] if t>>i&1 else b[i]) for t in expanded] for i in range(n)]
        target=[sum(values[i][g] for g,o in enumerate(own) if o==i) for i in range(n)]
        for i in range(n):
            for j in range(n):
                bundle=[g for g,o in enumerate(own) if o==j]
                for removed in bundle:
                    checks+=1
                    assert target[i]>=sum(values[i][g] for g in bundle if g!=removed),(index,'EFX')
        allU=hs*a+ls*b
        dom=(allU>=target).all(axis=1)&(allU>target).any(axis=1)
        assert not dom.any(),(index,'PO')
        cellcount+=1
    out={'status':'PASS','certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
         'cells_verified':cellcount,'witnesses_verified':len(witnesses),
         'literal_single_good_removal_checks':checks,
         'complete_labelled_core_and_low_count_classes_per_cell':len(hs),
         'complete_ownership_class_comparisons':cellcount*len(hs),
         'interior_representatives':'Mediants; unbounded tail uses lower endpoint+2. Builder uses midpoints and lower endpoint+1.',
         'dependencies':'Python standard library and NumPy only; no project solver imports.',
         'scope':'Each cell has a complete literal EFX witness globally undominated among every complete integral allocation. The row comparison-cell sign proof extends to all real ratios>1. This is only the fixed12-good incidence family.'}
    (D/'verify-candidate-ratio-cells.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':run()
